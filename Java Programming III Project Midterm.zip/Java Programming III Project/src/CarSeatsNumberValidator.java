public class CarSeatsNumberValidator{
    public void validateCarSeats(int car_seats) throws InvalidSeatNumberException{
        if (car_seats < 2 || car_seats > 7){
            throw new InvalidSeatNumberException("Car seats must be between 1 and 7!");
        }
    }
}


