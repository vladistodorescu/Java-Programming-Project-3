public class CarAndDifference2Budget implements Comparable<CarAndDifference2Budget> {
    Car car;
    int difference;

    public CarAndDifference2Budget(Car car, int difference) {
        this.car = car;
        this.difference = difference;
    }

    @Override
    public int compareTo(CarAndDifference2Budget other) {
        if (this.difference > other.difference) {
            return 1;
        }
        if (this.difference < other.difference) {
            return -1;
        }
        return 0;
    }
}


