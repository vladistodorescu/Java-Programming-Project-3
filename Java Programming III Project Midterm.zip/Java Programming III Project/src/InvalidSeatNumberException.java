public class InvalidSeatNumberException extends Exception{
    public InvalidSeatNumberException(String message){
        super(message);
    }
}


