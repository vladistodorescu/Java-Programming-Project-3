import java.util.ArrayList;

public class Seller implements ClientManagement{
    String seller_name;
    protected String seller_role;
    protected String seller_phoneNumber;
    protected String password;
    protected String username;
    protected ArrayList<Client> clients = new ArrayList<>();

    public Seller(String name, String role, String phoneNumber, String password, String username) {
        this.seller_name = name;
        this.seller_role = role;
        this.seller_phoneNumber = phoneNumber;
        this.password = password;
        this.username = username;
    }

    @Override
    public void addClient(Client client) {
        this.clients.add(client);
    }


    @Override
    public void listClients(){
        System.out.println(this.seller_name + "'s list of Clients:");

        int counter = 1;
        for (Client client : clients){
            System.out.println("Client " + counter + ": " + client.client_name);
            counter++;
        }
    }


}

