public interface ClientManagement{
    public void addClient(Client client);
    public void listClients();
}
