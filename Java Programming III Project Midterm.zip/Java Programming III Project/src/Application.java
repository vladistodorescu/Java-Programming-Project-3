public class Application{
    private InputDevice inputDevice;
    private OutputDevice outputDevice;

    public Application(InputDevice inputDevice, OutputDevice outputDevice){
        this.inputDevice = inputDevice;
        this.outputDevice = outputDevice;
    }

}
