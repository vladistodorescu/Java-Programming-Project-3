public interface ComparableSupercar<SuperCar>{
    public int compareTo(SuperCar supercar);
}

