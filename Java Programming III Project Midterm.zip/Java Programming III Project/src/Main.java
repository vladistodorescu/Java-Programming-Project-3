import java.io.*;
import java.util.*;

public class Main {

    private static ArrayList<Seller> loadSellers(String filepath){
        ArrayList<Seller> sellers = new ArrayList<>();
        String line = "";
        String delimiter = ",";

        try(BufferedReader bufferedReader = new BufferedReader(new FileReader(filepath))){
            while((line = bufferedReader.readLine()) != null){
                String[] details = line.split(delimiter);
                String name = details[0];
                String role = details[1];
                String phone_number = details[2];
                String password = details[3];
                String username = details[4];
                Seller new_seller = new Seller(name, role, phone_number, password, username);
                sellers.add(new_seller);
            }
        }
        catch (FileNotFoundException e){
            OutputDevice.writeToTerminal("The file '" + filepath + "' does not exist.");
        }
        catch (IOException e){
            OutputDevice.writeToTerminal("An error has occurred while reading the 'Sellers.csv' file.");
        }
        catch (ArrayIndexOutOfBoundsException e){
            OutputDevice.writeToTerminal("An array index has stepped out of bounds while reading the 'Sellers.csv' file.");
        }

        return sellers;
    }

    private static ArrayList<Car> loadCars(String filepath){
        ArrayList<Car> cars = new ArrayList<>();
        String line = "";
        String delimiter = ",";

        try (BufferedReader buffered_reader = new BufferedReader(new FileReader(filepath))){
            while ((line = buffered_reader.readLine()) != null){
                String[] values = line.split(delimiter);
                String brand = values[0];
                String model = values[1];
                String color = values[2];
                String owner = values[3];
                int top_speed = Integer.parseInt(values[4]);
                int life_expectancy = Integer.parseInt(values[5]);
                int year = Integer.parseInt(values[6]);
                int price = Integer.parseInt(values[7]);
                int seats = Integer.parseInt(values[8]);
                Car new_car = new Car(brand, model, color, owner, top_speed, life_expectancy, year, price, seats);
                cars.add(new_car);
            }
        }
        catch (FileNotFoundException e){
            OutputDevice.writeToTerminal("The file '" + filepath + "' does not exist.");
        }
        catch (IOException e){
            OutputDevice.writeToTerminal("An error has occurred while reading the 'Cars.csv' file.");
        }
        catch (ArrayIndexOutOfBoundsException e){
            OutputDevice.writeToTerminal("An array index has stepped out of bounds while reading the 'Cars.csv' file.");
        }

        return cars;
    }

    private static ArrayList<Client> loadClients(String filepath){
        ArrayList<Client> clients = new ArrayList<>();
        String line = "";
        String delimiter = ",";

        try (BufferedReader buffered_reader = new BufferedReader(new FileReader(filepath))){
            while((line = buffered_reader.readLine()) != null){
                String[] values = line.split(delimiter);
                String client_name = values[0];
                String client_bday = values[1];
                int budget = Integer.parseInt(values[2]);
                Client client = new Client(client_name, client_bday, budget);
                clients.add(client);
            }
        }
        catch (FileNotFoundException e){
            OutputDevice.writeToTerminal("The file '" + filepath + "' does not exist.");
        }
        catch (IOException e){
            OutputDevice.writeToTerminal("An error has occurred while reading the 'Clients.csv' file.");
        }
        catch (ArrayIndexOutOfBoundsException e){
            OutputDevice.writeToTerminal("An array index has stepped out of bounds while reading the 'Clients.csv' file.");
        }

        return clients;
    }

    private static void writeSellers(ArrayList<Seller> sellers, String filepath){
        try (FileWriter file_writer = new FileWriter(filepath)){
            for (Seller seller: sellers){
                file_writer.append(seller.seller_name + "," + seller.seller_role + "," + seller.seller_phoneNumber + "," + seller.password + "," + seller.username + "\n");
            }
            OutputDevice.writeToTerminal("The 'Sellers.csv' file has been succesfully updated.");
        }
        catch (IOException e){
            OutputDevice.writeToTerminal("An error has occurred while writing to the 'Sellers.csv' file.");
        }
    }

    private static void writeCars(ArrayList<Car> cars, String filepath){
        try (FileWriter file_writer = new FileWriter(filepath)){
            for (Car car : cars){
                file_writer.append(car.brand + "," + car.model + "," + car.color + "," + car.ownedBy + "," + car.topSpeed + "," + car.lifeExpectancy + "," + car.yearOfProduction + "," + car.price + "," + car.seats + "\n");
            }
            OutputDevice.writeToTerminal("The 'Cars.csv' file has been succesfully updated.");
        }
        catch (IOException e){
            OutputDevice.writeToTerminal("An error has occurred while writing to the 'Cars.csv' file.");
        }
    }

    private static void writeClients(ArrayList<Client> clients, String filepath){
        try (FileWriter file_writer = new FileWriter(filepath)){
            for (Client client : clients){
                file_writer.append(client.client_name + "," + client.client_birthDate + "," + client.budget + "\n");
            }
            OutputDevice.writeToTerminal("The 'Clients.csv' file has been succesfully updated.");
        }
        catch (IOException e){
            OutputDevice.writeToTerminal("An error has occurred while writing to the 'Clients.csv' file.");
        }
    }

    private static Car createNewCar(){
        Scanner scanner = new Scanner(System.in);

        OutputDevice.writeToTerminal("Please enter the car's brand: ");
        String car_brand = scanner.next();
        scanner.nextLine();

        OutputDevice.writeToTerminal("Please enter the car's model: ");
        String car_model = scanner.next();
        scanner.nextLine();

        OutputDevice.writeToTerminal("Please enter the car's color: ");
        String car_color = scanner.next();
        scanner.nextLine();

        OutputDevice.writeToTerminal("Please enter the car's ownership: ");
        String car_ownership = scanner.next();
        scanner.nextLine();

        OutputDevice.writeToTerminal("Please enter the car's top speed: ");
        int car_top_speed = scanner.nextInt();
        scanner.nextLine();

        OutputDevice.writeToTerminal("Please enter the car's life expectancy: ");
        int car_life_expectancy = scanner.nextInt();
        scanner.nextLine();

        OutputDevice.writeToTerminal("Please enter the car's year of production: ");
        int car_year = scanner.nextInt();
        scanner.nextLine();

        OutputDevice.writeToTerminal("Please enter the car's number of seats: ");
        int car_seats = 0;
        CarSeatsNumberValidator carSeatsNumberValidator = new CarSeatsNumberValidator();

        try{
            car_seats = scanner.nextInt();
            scanner.nextLine();
            carSeatsNumberValidator.validateCarSeats(car_seats);
        } catch (InvalidSeatNumberException e) {
            OutputDevice.writeToTerminal(e.getMessage());
            OutputDevice.writeToTerminal("Unfortunately the new Car record has not been created.");
            return null;
        }

        OutputDevice.writeToTerminal("Please enter the car's price: ");
        int car_price = 0;
        PriceValidator priceValidator = new PriceValidator();

        try{
            car_price = scanner.nextInt();
            scanner.nextLine();
            priceValidator.validatePrice(car_price);
        }
        catch (InvalidPriceException e) {
            OutputDevice.writeToTerminal(e.getMessage());
            OutputDevice.writeToTerminal("Unfortunately the new Car record has not been created.\n");
            return null;
        }

        return new Car(car_brand, car_model, car_color, car_ownership, car_top_speed, car_life_expectancy, car_year, car_price, car_seats);
    }

    private static Client createNewClient(){
        Scanner scanner = new Scanner(System.in);

        OutputDevice.writeToTerminal("Please enter the clients' first name:");
        String client_first_name = scanner.next();
        scanner.nextLine();

        OutputDevice.writeToTerminal("Please enter the clients' last name:");
        String client_last_name = scanner.next();
        scanner.nextLine();

        String client_name = client_first_name + " " + client_last_name;

        OutputDevice.writeToTerminal("Please enter the client's date of birth:");
        String client_date_of_birth = scanner.next();
        scanner.nextLine();

        BudgetValidator budgetValidator = new BudgetValidator();
        int client_budget = 0;

        try{
            OutputDevice.writeToTerminal("Please enter the client's budget:");
            client_budget = scanner.nextInt();
            scanner.nextLine();
            budgetValidator.validateBudget(client_budget);
        }
        catch (InvalidBudgetException e){
            OutputDevice.writeToTerminal(e.getMessage());
            OutputDevice.writeToTerminal("Unfortunately, the Client account has not been created.\n");
            return null;
        }

        return new Client(client_name, client_date_of_birth, client_budget);
    }

    private static void presentChoices(){
        OutputDevice.writeToTerminal("");
        OutputDevice.writeToTerminal("What would you like to do?");
        OutputDevice.writeToTerminal("[1] Present all cars in the catalog");
        OutputDevice.writeToTerminal("[2] Find best 5 cars according to given budget");
        OutputDevice.writeToTerminal("[3] Store information about a new client");
        OutputDevice.writeToTerminal("[4] Add a new car to the company's collection");
    }

    private static void intro(){
        OutputDevice.writeToTerminal("Hello and welcome to Java Programming III Project!\n");
        OutputDevice.writeToTerminal("This project is a Java application to help a car selling company \nstore, update and work with data they find useful.\n");
    }

    public static void main(String[] args){
        intro();

        Scanner scanner = new Scanner(System.in);

        String file_path_to_sellers_csv = "/Users/vladistodorescu/IdeaProjects/Java Programming III Project/src/Sellers.csv";
        ArrayList<Seller> sellers = loadSellers(file_path_to_sellers_csv);

        OutputDevice.writeToTerminal("Please enter your credentials to log in to your profile!");

        // ---------- Login in the application ----------

        Seller logged_in_seller = null;

        boolean allowed_login = false;
        int allowed_mistakes = 3;

        while (allowed_mistakes > 0){
            OutputDevice.writeToTerminal("Username:");
            String username = scanner.nextLine();
            OutputDevice.writeToTerminal("Password:");
            String password = scanner.nextLine();
            for (Seller seller: sellers){
                if (Objects.equals(seller.username, username)){
                    if (Objects.equals(seller.password, password)){
                        allowed_login = true;
                        logged_in_seller = seller;
                    }
                }
            }
            if (allowed_login){
                allowed_mistakes = 0;
            }
            else{
                allowed_mistakes--;
                OutputDevice.writeToTerminal("Unfortunately, the username or password is incorrect. Please try again! (" + allowed_mistakes + " tries left)\n");
            }
        }

        // ---------- Read the Cars.csv file and load the data into the ArrayList ----------

        String file_path_to_cars_csv = "/Users/vladistodorescu/IdeaProjects/Java Programming III Project/src/Cars.csv";
        ArrayList<Car> cars = loadCars(file_path_to_cars_csv);

        // ---------- Read the Clients.csv file and load the data into the ArrayList ----------

        String file_path_to_clients_csv = "/Users/vladistodorescu/IdeaProjects/Java Programming III Project/src/Clients.csv";
        ArrayList<Client> clients = loadClients(file_path_to_clients_csv);

        // ---------- Menu for the app ----------

        boolean correct_choice = false;
        while (!correct_choice){
            presentChoices();
            int choice = 0;
            try{
                choice = scanner.nextInt();
            }
            catch (InputMismatchException e){
                OutputDevice.writeToTerminal("You have inputted a wrong data type!");
                scanner.nextLine();
            }
            switch (choice){
                case 1:
                    int counter_case_1 = 1;
                    for (Car car : cars){
                        OutputDevice.writeToTerminal("Car " + counter_case_1 + ": ");
                        car.displayVehicleInformation();
                        counter_case_1++;
                    }

                    correct_choice = true;
                    break;

                case 2:
                    OutputDevice.writeToTerminal("Please enter your budget: ");
                    int budget = scanner.nextInt();

                    ArrayList<CarAndDifference2Budget> cars_and_differences = new ArrayList<>();
                    for (Car car : cars){
                        int difference = Math.abs(budget - car.price);
                        Car car_to_add = car;
                        CarAndDifference2Budget new_set = new CarAndDifference2Budget(car_to_add, difference);
                        cars_and_differences.add(new_set);
                    }

                    cars_and_differences.sort((a, b) -> Integer.compare(a.difference, b.difference));

                    OutputDevice.writeToTerminal("The best 5 cars suiting your budget are:\n");

                    int counter_case_2 = 1;
                    for (CarAndDifference2Budget car_and_dif: cars_and_differences){
                        if (counter_case_2 == 6){
                            break;
                        }
                        else{
                            OutputDevice.writeToTerminal("Car " + counter_case_2);
                            car_and_dif.car.displayVehicleInformation();
                            counter_case_2++;
                        }
                    }

                    correct_choice = true;
                    break;

                case 3:
                    Client new_client = createNewClient();

                    if (new_client != null){
                        clients.add(new_client);
                        assert logged_in_seller != null;  // to avoid NullPointerException
                        logged_in_seller.addClient(new_client);
                        OutputDevice.writeToTerminal("The Client account has been created and assigned to your clients list.\n");
                    }

                    correct_choice = true;
                    break;
                case 4:
                    Car new_car = createNewCar();

                    if (new_car != null){
                        cars.add(new_car);
                        OutputDevice.writeToTerminal("The Car record has been created and added to the collection.\n");
                    }

                    correct_choice = true;
                    break;
                default:
                    OutputDevice.writeToTerminal("Invalid choice. Try again.\n");
                    break;
            }

        }

        // ---------- Write the end results in the csv files for data persistence ---------- (nu am mai facut FileNotFoundException pentru ca ar da crash la inceput)

        writeSellers(sellers, file_path_to_sellers_csv);
        writeCars(cars, file_path_to_cars_csv);
        writeClients(clients, file_path_to_clients_csv);

        scanner.close();

        // Car firstCar = new Car("Mercedes", "CLA", "Black", "AutoKlass", 243, 15, 2000, 20000, 5);
        // firstCar.remainingLifeOfCar();
        // Seller seller1 = new Seller("Mihai Gabriel", "Sales Manager", "0743217151");
        // Client client1 = new Client("Marius Maruta", "12/07/2003", "Mercedes", 20000);
        // seller1.addClient(client1);
        // seller1.listOfClients();
        // firstCar.displayVechicleInformation();
        // seller1.addClient(client1);
        // seller1.listClients();

        // Car supercar1 = new SuperCar("Ferrari", "Testarossa", "Red", "AutoKlass", 243, 15, 2000, 200000, 2);
        // SuperCar supercar2 = new SuperCar("Lamborghini", "Aventador", "Yellow", "AutoKlass", 342, 24, 2012, 243000, 2);
        // System.out.println(supercar1.compareTo(supercar2));

        // Car familycar1 = new FamilyCar("Mercedes", "V200", "Red", "AutoKlass", 189, 15, 2000, 40000, 7);
        // FamilyCar familycar2 = new FamilyCar("Ford", "Kuga","Yellow", "AutoKlass", 178, 24, 2012, 243000, 5);
        // System.out.println(familycar1.compareTo(familycar2));

        // client1.bestSuitedCars.add(firstCar);
        // client1.bestSuitedCars.add(supercar1);
        // client1.bestSuitedCars.add(familycar1);
        // client1.listBestSuitedCarsAscendingly();

        // System.out.println();

        // client1.listBestSuitedCarsDescendingly();

    }
}





