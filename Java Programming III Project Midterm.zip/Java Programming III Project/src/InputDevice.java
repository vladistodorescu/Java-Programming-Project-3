public class InputDevice{

}
