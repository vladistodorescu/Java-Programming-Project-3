public class OutputDevice{
    public static void writeToTerminal(String message){ System.out.println(message);}
}

