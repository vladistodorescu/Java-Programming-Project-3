import java.time.LocalDate;
import java.util.ArrayList;

public class Car implements VehicleOperations{
    protected String brand;
    protected String model;
    protected String color;
    protected int topSpeed;
    protected int lifeExpectancy;
    protected int yearOfProduction;
    protected String ownedBy;
    protected int price;
    protected int seats;


    public Car(String brand, String model, String color, String ownedBy, int topSpeed, int lifeExpectancy, int yearOfProduction, int price, int seats) {
        this.brand = brand;
        this.model = model;
        this.color = color;
        this.topSpeed = topSpeed;
        this.lifeExpectancy = lifeExpectancy;
        this.yearOfProduction = yearOfProduction;
        this.ownedBy = ownedBy;
        this.price = price;
        this.seats = seats;
    }

    public void remainingLifeOfCar(){
        int yearOfProduction = this.yearOfProduction;
        int lifeExpectancy = this.lifeExpectancy;
        int currentYear = LocalDate.now().getYear();
        int lifeRemaining = lifeExpectancy - (currentYear - yearOfProduction);
        if (lifeRemaining <= 0){
            OutputDevice.writeToTerminal("Unfortunately, this car has no more years of guaranteed functioning remaining.");
        }
        else{
            OutputDevice.writeToTerminal("This car has about " + lifeRemaining + " years of guaranteed functioning remaining.");
        }
    }

    @Override
    public void displayVehicleInformation(){
        OutputDevice.writeToTerminal("Brand: "  + this.brand + "\n" + "Model: " + this.model + "\n"
                + "Color: " + this.color + "\n" +"Seats: " + this.seats +  "\n" + "Top Speed: " + this.topSpeed
                + " km/h\n" + "Year of Production: " + this.yearOfProduction + "\n" + "Price: " + this.price + "\n");
    }

    @Override
    public void scheduleMaintenance() {
        OutputDevice.writeToTerminal("Car maintenance scheduled.");
    }





}



