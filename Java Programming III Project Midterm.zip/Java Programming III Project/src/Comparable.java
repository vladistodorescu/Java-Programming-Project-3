public interface Comparable<CarAndDifference2Budget> {
    public int compareTo(CarAndDifference2Budget carAndDif2Budget);
}
