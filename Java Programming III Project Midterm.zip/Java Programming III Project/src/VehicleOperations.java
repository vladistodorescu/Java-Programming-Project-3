public interface VehicleOperations{
    void displayVehicleInformation();
    void scheduleMaintenance();
}


