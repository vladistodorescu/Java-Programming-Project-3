import java.util.ArrayList;
import java.util.Collections;

public class Client {
    protected String client_name;
    protected String client_birthDate;
    protected int budget;
    protected Seller relatedSellers;
    protected ArrayList<Car> bestSuitedCars = new ArrayList<>();

    public Client(String name, String birthDate, int budget) {
        this.client_name = name;
        this.client_birthDate = birthDate;
        this.budget = budget;
    }

    public void addProspectCar(Car car){
        this.bestSuitedCars.add(car);
    }

    public void listBestSuitedCarsAscendingly(){
        Collections.sort(this.bestSuitedCars, (car1, car2) -> Integer.compare(car1.price, car2.price));
        int i = 1;
        for (Car car : bestSuitedCars){
            OutputDevice.writeToTerminal(i + ". " + car.brand + " " + car.model);
            i++;
        }
    }

    public void listBestSuitedCarsDescendingly(){
        Collections.sort(this.bestSuitedCars, (car1, car2) -> Integer.compare(car2.price, car1.price));
        int i = 1;
        for (Car car : bestSuitedCars){
            OutputDevice.writeToTerminal(i + ". " + car.brand + " " + car.model);
            i++;
        }
    }

}
