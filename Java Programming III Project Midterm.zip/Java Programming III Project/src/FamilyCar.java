public class FamilyCar extends Car implements VehicleOperations, ComparableFamilyCar<FamilyCar> {

    public FamilyCar(String brand, String model, String color, String ownedBy, int topSpeed, int lifeExpectancy, int yearOfProduction, int price, int seats){
        super(brand, model, color, ownedBy, topSpeed, lifeExpectancy, yearOfProduction, price, 7);
    }

    @Override
    public void displayVehicleInformation(){
        OutputDevice.writeToTerminal("Looking for a family car? It offers spacious seating, advanced safety features," +
                " and excellent fuel efficiency for comfortable and economical journeys.");
        OutputDevice.writeToTerminal("Car Details:\n" + "Brand: "  + this.brand + "\n" + "Model: " +
                this.model + "\n" + "Color: " + this.color + "\n" + "Top Speed: " + this.topSpeed + " km/h\n" + "Year of Production: "
                + this.yearOfProduction + "\n" + "Price: " + this.price + "\n");
    }

    @Override
    public void scheduleMaintenance() {
        OutputDevice.writeToTerminal("Car maintenance started.");
    }

    // returns an integer referring to which family car has more seats
    @Override
    public int compareTo(FamilyCar other){
        if (this.seats > other.seats){
            return 1;
        }
        else if (this.seats < other.seats){
            return -1;
        }
        else{
            return 0;
        }
    }


}
