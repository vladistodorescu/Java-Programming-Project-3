public class BudgetValidator {
    public void validateBudget(int budget) throws InvalidBudgetException{
        if(budget < 0){
            throw new InvalidBudgetException("The budget cannot be negative!");
        }
    }
}

