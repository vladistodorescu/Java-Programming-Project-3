public class PriceValidator {
    public void validatePrice(int price) throws InvalidPriceException{
        if (price < 0){
            throw new IllegalArgumentException("Price must be a positive number!");
        }
    }
}

