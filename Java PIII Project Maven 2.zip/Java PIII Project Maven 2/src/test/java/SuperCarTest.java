import org.example.OutputDevice;
import org.example.SuperCar;
import org.example.Car;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class SuperCarTest {
    private SuperCar superCar1;
    private SuperCar superCar2;

    @BeforeEach
    void setUp() {
        superCar1 = new SuperCar("Audi", "R8", "YELLOW", "Autoklass", 232, 13, 2013, 47000);
        superCar2 = new SuperCar("Ferrari", "458", "RED", "Autoklass", 276, 15, 2017, 94000);
    }

    @Test
    void testDisplayVehicleInformation(){
        assertDoesNotThrow(() -> superCar1.displayVehicleInformation(), "The displayVehicleInformation() method encountered an error along the way!");
    }

    @Test
    void testScheduleMaintenance(){
        assertDoesNotThrow(() -> superCar1.scheduleMaintenance(), "The scheduleMaintenance() method encountered an error along the way!");
    }

    @Test
    void testCompareTo(){
        OutputDevice.writeToTerminal("testCompareTo()");

        assertEquals(superCar1.compareTo(superCar2), -1, "The compareTo() method encountered an error along the way!");
        assertEquals(superCar2.compareTo(superCar1), 1, "The compareTo() method encountered an error along the way!");
        assertEquals(superCar2.compareTo(superCar2), 0, "The compareTo() method encountered an error along the way!");
    }

}
