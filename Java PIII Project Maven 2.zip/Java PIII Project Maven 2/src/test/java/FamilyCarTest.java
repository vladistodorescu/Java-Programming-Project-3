import org.example.FamilyCar;
import org.example.OutputDevice;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FamilyCarTest {

    private FamilyCar familyCar1;
    private FamilyCar familyCar2;
    private FamilyCar familyCar3;

    @BeforeEach
    void setUp() {
        familyCar1 = new FamilyCar("Mercedes", "V200", "RED", "Autoklass", 172, 9, 2012, 27000, 7);
        familyCar2 = new FamilyCar("Mercedes", "V700", "RED", "Autoklass", 212, 7, 2010, 23000, 8);
        familyCar3 = new FamilyCar("Mercedes", "V500", "RED", "Autoklass", 182, 6, 2013, 28000, 7);
    }

    @Test
    void testDisplayVehicleInformation(){
        OutputDevice.writeToTerminal("Testing the displayVehicleInformation() method from the FamilyCar class -->");
        assertDoesNotThrow(() -> familyCar1.displayVehicleInformation());
        OutputDevice.writeToTerminal("");
    }

    @Test
    void testScheduleMaintenance(){
        OutputDevice.writeToTerminal("Testing the scheduleMaintenance() method from the FamilyCar class -->");
        assertDoesNotThrow(() -> familyCar1.scheduleMaintenance());
        OutputDevice.writeToTerminal("");
    }

    @Test
    void testCompareTo(){
        int assert1 = familyCar1.compareTo(familyCar2); // 7.compareTo.8 --> -1
        OutputDevice.writeToTerminal(assert1 + "");
        int assert2 = familyCar2.compareTo(familyCar3); // 8.compareTo.7 --> 1
        OutputDevice.writeToTerminal(assert2 + "");
        assertEquals(-1, assert1);
        assertEquals(1, assert2);
    }

}
