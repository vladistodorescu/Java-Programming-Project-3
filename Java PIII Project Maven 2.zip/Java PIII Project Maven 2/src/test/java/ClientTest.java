import org.example.Client;
import org.example.Car;
import org.example.OutputDevice;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;


public class ClientTest {

    private Client client;
    private Car car1;
    private Car car2;

    @BeforeEach
    void SetUp(){
        client = new Client("Mihail Vasilean", "12/07/2000", 8900);
        car1 = new Car("Mercedes", "SLK200", "RED", "Autoklass", 193, 7, 2000, 3000, 2);
        car2 = new Car("Mercedes", "CLS", "RED", "Autoklass", 201, 7, 2000, 34000, 2);
    }

    @Test
    void testAddProspectCar(){
        client.addProspectCar(car1);

        assertTrue(client.bestSuitedCars.contains(car1), "The ArrayList bestSuitedCars should contain car1!");
    }

    @Test
    void testRetrieveProspectCars() {
        client.addProspectCar(car1);
        client.addProspectCar(car2);

        ArrayList<Car> prospectCars = client.retrieveProspectCars();

        assertEquals(prospectCars.size(), 2, "The ArrayList bestSuitedCars should have size 2!");

        assertTrue(prospectCars.contains(car1), "The ArrayList prospectCars, retrieved with the retrieveProspectCars should contain car1!");
        assertTrue(prospectCars.contains(car2), "The ArrayList prospectCars, retrieved with the retrieveProspectCars should contain car2!");
    }

    @Test
    void testListBestSuitedCarsAscending(){
        OutputDevice.writeToTerminal("Testing the listBestSuitedCarsAscending() function from the Client class");
        client.bestSuitedCars = new ArrayList<>();

        client.bestSuitedCars.add(car1);
        client.bestSuitedCars.add(car2);

        OutputDevice.writeToTerminal("The best suited cars listed ascending by price:");

        client.listBestSuitedCarsAscendingly();

        assertEquals(car1.price, client.bestSuitedCars.get(0).price, "The price of the first car in the arrayList should be 3000!");
        assertEquals(car2.price, client.bestSuitedCars.get(1).price, "The price of the second car in the arrayList should be 34000!");

        OutputDevice.writeToTerminal("");
    }

    @Test
    void testListBestSuitedCarsDescending(){
        OutputDevice.writeToTerminal("Testing the listBestSuitedCarsDescending() function from the Client class:");
        client.bestSuitedCars = new ArrayList<>();

        client.bestSuitedCars.add(car1);
        client.bestSuitedCars.add(car2);

        OutputDevice.writeToTerminal("The best suited cars listed descending by price:");

        client.listBestSuitedCarsDescendingly();

        assertEquals(car1.price, client.bestSuitedCars.get(1).price, "The price of the first car in the arrayList should be 34000!");
        assertEquals(car2.price, client.bestSuitedCars.get(0).price, "The price of the first car in the arrayList should be 3000!");

        OutputDevice.writeToTerminal("");
    }

}
