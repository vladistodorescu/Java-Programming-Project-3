import org.example.Car;
import org.example.OutputDevice;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CarTest {

    private Car car;

    @BeforeEach
    void setUp(){
        car = new Car(
                "Toyota",
                "Corolla",
                "Blue",
                "John Doe",
                180,
                15,
                2010,
                8000,
                5
        );
    }

    @Test
    void testDisplayVehicleInformation(){
        OutputDevice.writeToTerminal("Testing the displayVehicleInformation() function from the Car class:");
        assertDoesNotThrow(() -> car.displayVehicleInformation());
        OutputDevice.writeToTerminal("");
    }

    @Test
    void testScheduleMaintenance(){
        OutputDevice.writeToTerminal("Testing the scheduleMaintenance() function from the Car class:");
        assertDoesNotThrow(() -> car.scheduleMaintenance());
        OutputDevice.writeToTerminal("");
    }

}

