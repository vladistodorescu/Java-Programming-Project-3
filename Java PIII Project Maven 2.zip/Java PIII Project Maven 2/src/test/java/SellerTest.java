import org.example.Client;
import org.example.Seller;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class SellerTest {
    private Seller seller;
    private Client client1;
    private Client client2;

    @BeforeEach
    void setUp() {
        seller = new Seller("Mihai Gabriel", "Sales Manager", "0743217151", "parola123", "mgabriel");
        client1 = new Client("Marian Maricel", "22/09/1998", 3400);
        client2 = new Client("Adrian Belea", "32/09/1979", 5300);
    }

    @Test
    void testAddClient() {
        seller.addClient(client1);
        seller.addClient(client2);

        List<Client> clients = seller.getClients();

        assertEquals(clients.size(), 2, "The list should contain 2 clients!");

        assertTrue(clients.contains(client1), "The clients list should contain client1!");
        assertTrue(clients.contains(client2), "The clients list should contain client2!");
    }

    @Test
    void testListClients(){
        seller.addClient(client1);
        seller.addClient(client2);

        assertDoesNotThrow(() -> seller.listClients());
    }

    // modify the returned list and assert that the clients list in Seller is unchanged

    @Test
    public void testGetClientsReturnsCopy() {
        seller.addClient(client1);

        List<Client> clients = seller.getClients();

        clients.add(client2);

        assertEquals(1, seller.getClients().size(), "The original clients list should not be modified.");
        assertTrue(seller.getClients().contains(client1), "The original clients list should still contain Client 1.");
        assertFalse(seller.getClients().contains(client2), "The original clients list should not contain Client 2.");
    }

}
