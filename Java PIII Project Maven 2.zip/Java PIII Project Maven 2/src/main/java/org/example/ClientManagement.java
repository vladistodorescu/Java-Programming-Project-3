package org.example;

import java.util.List;

public interface ClientManagement{
    public void addClient(Client client);
    public void listClients();
    public List<Client> getClients();
}
