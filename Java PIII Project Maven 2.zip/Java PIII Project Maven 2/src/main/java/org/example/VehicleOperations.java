package org.example;

public interface VehicleOperations{
    void displayVehicleInformation();
    void scheduleMaintenance();
}


