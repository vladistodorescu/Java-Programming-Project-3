package org.example;

public class InputDevice{

}
