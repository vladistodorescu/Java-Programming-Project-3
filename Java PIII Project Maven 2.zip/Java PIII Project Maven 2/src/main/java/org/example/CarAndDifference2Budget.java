package org.example;

public class CarAndDifference2Budget implements Comparable<CarAndDifference2Budget> {
    Car car;
    int difference;

    public CarAndDifference2Budget(Car car, int difference) {
        this.car = car;
        this.difference = difference;
    }

    @Override
    public int compareTo(CarAndDifference2Budget other) {
        if (this.difference > other.difference) {
            return 1;
        }
        if (this.difference < other.difference) {
            return -1;
        }
        return 0;
    }

    public Car getCar() {
        return car;
    }

    public int getDifference() {
        return difference;
    }

    public String getBrand() {
        return car != null ? car.getBrand() : null;
    }

    public String getModel() {
        return car != null ? car.getModel() : null;
    }

}


