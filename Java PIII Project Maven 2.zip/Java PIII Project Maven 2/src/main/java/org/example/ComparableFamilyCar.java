package org.example;

public interface ComparableFamilyCar<FamilyCar>{
    public int compareTo(FamilyCar familyCar);
}



