package org.example;

public class SuperCar extends Car implements VehicleOperations, ComparableSupercar<SuperCar>{

    public SuperCar(String brand, String model, String color, String ownedBy, int topSpeed, int lifeExpectancy, int yearOfProduction, int price){
        super(brand, model, color, ownedBy, topSpeed, lifeExpectancy, yearOfProduction, price, 2);
    }

    @Override
    public void displayVehicleInformation(){
        OutputDevice.writeToTerminal("Looking for a supercar? It offers boasting unmatched speed, cutting-edge design," +
                "and high-performance handling for an unparalleled driving experience.");
        OutputDevice.writeToTerminal("Car Details:\n" + "Brand: "  + this.brand + "\n" + "Model: " + this.model + "\n"
                + "Color: " + this.color + "\n" + "Top Speed: " + this.topSpeed + " km/h\n" + "Year of Production: "
                + this.yearOfProduction + "\n" + "Price: " + this.price + "\n");
    }

    @Override
    public void scheduleMaintenance() {
        OutputDevice.writeToTerminal("Car maintenance scheduled.");
    }

    // returns an integer referring to which supercar car has a greater top speed
    @Override
    public int compareTo(SuperCar other) {
        if (this.topSpeed > other.topSpeed) {
            return 1;
        } else if (this.topSpeed < other.topSpeed) {
            return -1;
        } else {
            return 0;
        }
    }

}

