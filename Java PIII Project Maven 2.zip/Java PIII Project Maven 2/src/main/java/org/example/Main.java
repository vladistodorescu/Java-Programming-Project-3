package org.example;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.http.*;
import java.net.URI;
import java.util.*;
import java.sql.*;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.concurrent.*;


public class Main extends Application {
    private VBox vbox = new VBox(10);
    private Scene scene = new Scene(vbox, 1200, 825);
    final String URL = "jdbc:mysql://localhost:3306/my_project_db";
    final String USER = "root";
    final String PASSWORD = "Patrubrate#2020";
    ArrayList<Seller> sellers = null;
    ArrayList<Car> cars = null;
    ArrayList<Client> clients = null;

    private static ArrayList<Seller> loadSellers(String URL, String USER, String PASS) {
        ArrayList<Seller> sellers = new ArrayList<>();

        String sql = "SELECT seller_name, seller_role, seller_phoneNumber, password, username FROM seller";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);   // connecting to the database
             Statement stmt = conn.createStatement();                          // statement is created to execute the query
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {                                                // while in the result set there is another row...
                String seller_name = rs.getString("seller_name");
                String seller_role = rs.getString("seller_role");
                String seller_phoneNumber = rs.getString("seller_phoneNumber");
                String password = rs.getString("password");
                String username = rs.getString("username");

                Seller seller = new Seller(seller_name, seller_role, seller_phoneNumber, password, username);
                sellers.add(seller);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return sellers;
    }

    private static ArrayList<Car> loadCars(String URL, String USER, String PASS) {
        ArrayList<Car> cars = new ArrayList<>();

        String sql = "SELECT brand, model, color, topSpeed, lifeExpectancy,yearOfProduction, ownedBy, price, seats FROM car";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String brand = rs.getString("brand");
                String model = rs.getString("model");
                String color = rs.getString("color");
                int topSpeed = rs.getInt("topSpeed");
                int lifeExpectancy = rs.getInt("lifeExpectancy");
                int yearOfProduction = rs.getInt("yearOfProduction");
                String ownedBy = rs.getString("ownedBy");
                int price = rs.getInt("price");
                int seats = rs.getInt("seats");

                Car car = new Car(brand, model, color, ownedBy, topSpeed, lifeExpectancy, yearOfProduction, price, seats);
                cars.add(car);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return cars;
    }

    private static ArrayList<Client> loadClients(String URL, String USER, String PASS) {
        ArrayList<Client> clients = new ArrayList<>();

        String sql = "SELECT client_name, client_birthDate, budget FROM client";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String client_name = rs.getString("client_name");
                String client_birthDate = rs.getString("client_birthDate");
                int budget = rs.getInt("budget");

                Client client = new Client(client_name, client_birthDate, budget);
                clients.add(client);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return clients;
    }

    private boolean writeClientToDatabase(Client client) {
        String sql = "INSERT INTO client (client_name, client_birthDate, budget) " +
                "VALUES (?, ?, ?) " +
                "ON DUPLICATE KEY UPDATE " +
                "budget = VALUES(budget)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, client.getClient_name());
            pstmt.setString(2, client.getClient_birthDate());
            pstmt.setInt(3, client.getBudget());

            int rowsAffected = pstmt.executeUpdate();

            return rowsAffected > 0; // Return true if the client was successfully added/updated
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }  // de tinut

    private boolean writeCarToDatabase(Car car) {
        String sql = "INSERT INTO car (brand, model, color, ownedBy, topSpeed, lifeExpectancy, yearOfProduction, price, seats) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) " +
                "ON DUPLICATE KEY UPDATE " +
                "brand = VALUES(brand)," +
                "color = VALUES(color), " +
                "ownedBy = VALUES(ownedBy), " +
                "topSpeed = VALUES(topSpeed), " +
                "lifeExpectancy = VALUES(lifeExpectancy), " +
                "yearOfProduction = VALUES(yearOfProduction), " +
                "price = VALUES(price), " +
                "seats = VALUES(seats)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, car.getBrand());
            pstmt.setString(2, car.getModel());
            pstmt.setString(3, car.getColor());
            pstmt.setString(4, car.getOwnedBy());
            pstmt.setInt(5, car.getTopSpeed());
            pstmt.setInt(6, car.getLifeExpectancy());
            pstmt.setInt(7, car.getYearOfProduction());
            pstmt.setDouble(8, car.getPrice());
            pstmt.setInt(9, car.getSeats());

            int rowsAffected = pstmt.executeUpdate();

            return rowsAffected > 0; // Return true if the car was successfully added/updated
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    } // de tinut

    private boolean applyDiscountToAllCarPricesInDatabase(int discountPercentage) {
        String sql = "UPDATE car SET price = price * (1 - ? / 100.0)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, discountPercentage); // Set the discount percentage
            int rowsAffected = pstmt.executeUpdate();

            return rowsAffected > 0; // Return true if at least one row was updated
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    } // de tinut

    private void loginScreen(Stage primaryStage) {

        ExecutorService executor = Executors.newFixedThreadPool(1);

        Future<ArrayList<Seller>> sellersFuture = executor.submit(() -> loadSellers(URL, USER, PASSWORD));

        try {
            sellers = sellersFuture.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            executor.shutdownNow();
        }

        executor.shutdown();

        Label intro = new Label("Hello and welcome to Java Individual Project!");
        Label intro_2 = new Label("This project is a Java application to help a car selling company store, update, and work with data they find useful.");
        Label intro_3 = new Label("Please connect with your Seller account to the platform:");


        TextField usernameField = new TextField();
        usernameField.setPromptText("Enter your name:");

        PasswordField passwordField = new PasswordField(); // For secure password input
        passwordField.setPromptText("Enter your password:");

        Button submitButton = new Button("Submit");

        Label loginStatusLabel = new Label();

        Label remainingAttemptsLabel = new Label("Remaining attempts: 3");


        final int[] allowedMistakes = {3}; // Use an array to modify inside the lambda

        submitButton.setOnAction(event -> {
            boolean allowedLogin = false;
            Seller logged_in_seller = null;

            for (Seller seller : sellers) {
                if (Objects.equals(seller.username, usernameField.getText()) &&
                        Objects.equals(seller.password, passwordField.getText())) {
                    allowedLogin = true;
                    logged_in_seller = seller;
                    break;
                }
            }

            if (allowedLogin) {
                loginStatusLabel.setText("Successful login!");
                OutputDevice.writeToTerminal("Successful login!");
                showHomePage(); // Navigate to the home page
            } else {
                allowedMistakes[0]--; // Decrement the remaining attempts
                if (allowedMistakes[0] > 0) {
                    loginStatusLabel.setText("Incorrect username or password. Please try again!");
                    remainingAttemptsLabel.setText("Remaining attempts: " + allowedMistakes[0]);
                    OutputDevice.writeToTerminal("Incorrect username or password. " + allowedMistakes[0] + " tries left.");
                } else {
                    loginStatusLabel.setText("No attempts left. Exiting the application...");
                    remainingAttemptsLabel.setText("Remaining attempts: 0");
                    OutputDevice.writeToTerminal("No attempts left. Exiting the application...");
                    System.exit(0); // Exit the program
                }
            }
        });

        // VBox layout to hold the components
        vbox.setPadding(new Insets(20, 50, 20, 50));
        vbox.setSpacing(10); // Spacing between elements
        vbox.getChildren().addAll(intro, intro_2, intro_3, usernameField, passwordField, submitButton, loginStatusLabel, remainingAttemptsLabel);

        // Set up the Stage
        primaryStage.setTitle("Java Individual Project");
        primaryStage.setScene(scene); // Ensure `scene` includes the VBox
        primaryStage.show();
    }

    private void showHomePage() {
        vbox.getChildren().clear();
        ExecutorService executor = Executors.newFixedThreadPool(2);

        Future<ArrayList<Car>> carsFuture = executor.submit(() -> loadCars(URL, USER, PASSWORD));
        Future<ArrayList<Client>> clientsFuture = executor.submit(() -> loadClients(URL, USER, PASSWORD));

        try {
            cars = carsFuture.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            executor.shutdownNow();
        }


        try {
            clients = clientsFuture.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            executor.shutdownNow();
        }

        executor.shutdown();

        Button presentAllCarsButton = new Button("Present all cars in the catalog!");
        Button findBestCarsButton = new Button("Find best 5 cars according to given budget!");
        Button newClientButton = new Button("Store information about a new client!");
        Button addNewCarButton = new Button("Add a new car to the collection!");
        Button addDiscountButton = new Button("Add a discount for all cars");
        Button giveCarIdeasButton = new Button("Give buyers car ideas");
        Button exitButton = new Button("Exit");

        vbox.setPadding(new Insets(20, 50, 20, 50));// spacing parameter sets the vertical space between nodes
        vbox.getChildren().addAll(presentAllCarsButton, findBestCarsButton, newClientButton, addNewCarButton, addDiscountButton, giveCarIdeasButton, exitButton);


        presentAllCarsButton.setOnAction(event -> {
            showAllCars();
        });

        findBestCarsButton.setOnAction(event -> {
            findBest5CarsInputScreen();
        });

        newClientButton.setOnAction(event -> {
            createNewClientScreen();
        });

        addNewCarButton.setOnAction(event -> {
            createNewCarScreen();
        });

        addDiscountButton.setOnAction(event -> {
            addDiscountToAllCars();
        });

        giveCarIdeasButton.setOnAction(event -> {
            giveCarIdeas();
        });

        exitButton.setOnAction(event -> {
            exit();
        });


    } // de tinut

    private void exit() {
        Alert exitAlert = new Alert(Alert.AlertType.CONFIRMATION);
        exitAlert.setTitle("Exit");
        exitAlert.setHeaderText("Are you sure you want to exit?");
        exitAlert.setContentText("Press OK to exit or Cancel to stay.");

        Optional<ButtonType> result = exitAlert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            System.exit(0);
        }
    } // de tinut

    private void giveCarIdeas() {
        vbox.getChildren().clear();

        try {
            String apiUrl = "https://api.unsplash.com/photos/random?query=car&client_id=VP03Q7kjRHCbu7Hr88X8KZAYpa4ghemL2p5eagnMOjs";
            HttpClient client = HttpClient.newHttpClient();  // apiURL making a request to Unspalsh API
            HttpRequest request = HttpRequest.newBuilder()  //  apiURL built on base URL, query parameter and API Key
                    .uri(URI.create(apiUrl))
                    .GET()
                    .build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) { // status 200 means OK
                String responseBody = response.body();
                ObjectMapper objectMapper = new ObjectMapper(); // we need an ObjectMapper object to convert the recieved
                JsonNode jsonNode = objectMapper.readTree(responseBody);  // data to json
                String carURL = jsonNode.get("urls").get("regular").asText();

                Image carImage = new Image(carURL, true);
                ImageView imageView = new ImageView(carImage);
                imageView.setFitWidth(600);
                imageView.setPreserveRatio(true);

                vbox.getChildren().add(imageView);
            } else {
                Label errorLabel = new Label("Failed to fetch image. Status Code: " + response.statusCode());
                vbox.getChildren().add(errorLabel);
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            Label errorLabel = new Label("An error occurred while fetching the image.");
            vbox.getChildren().add(errorLabel);
        }

        Button returnButton = new Button("Return");
        vbox.getChildren().add(returnButton);

        returnButton.setOnAction(event -> {
            showHomePage();
        });
    } // de tinut

    private void addDiscountToAllCars() {
        vbox.getChildren().clear();

        TextField discountPercentField = new TextField();
        discountPercentField.setPromptText("Enter your discount percent:");

        Button submitButton = new Button("Submit");
        Button returnButton = new Button("Return");

        vbox.setPadding(new Insets(20, 50, 20, 50));
        vbox.getChildren().addAll(discountPercentField, returnButton, submitButton);

        submitButton.setOnAction(event -> {
            int discount = Integer.parseInt(discountPercentField.getText());

            cars.parallelStream().forEach(car -> car.applyDiscount(discount));

            applyDiscountToAllCarPricesInDatabase(discount);

            Label successLabel = new Label("Discount applied successfully to all cars!");
            vbox.getChildren().add(successLabel);
        });

        returnButton.setOnAction(event -> {
            showHomePage();
        });
    } // de tinut

    private void createNewCarScreen(){
        vbox.getChildren().clear();

        TextField carBrand = new TextField();
        carBrand.setPromptText("Brand:");

        TextField carModel = new TextField();
        carModel.setPromptText("Model:");

        TextField carColor = new TextField();
        carColor.setPromptText("Color:");

        TextField carYear = new TextField();
        carYear.setPromptText("Top Speed:");

        TextField carLifeExpectancy = new TextField();
        carLifeExpectancy.setPromptText("Life Expectancy:");

        TextField carYearOfProduction = new TextField();
        carYearOfProduction.setPromptText("Year Of Production: ");

        TextField carOwnedby = new TextField();
        carOwnedby.setPromptText("Owned by:");

        TextField carPrice = new TextField();
        carPrice.setPromptText("Price:");

        TextField carSeats = new TextField();
        carSeats.setPromptText("Seats:");

        Button submitButton = new Button("Submit");
        Button returnButton = new Button("Return");

        vbox.setPadding(new Insets(20, 50, 20, 50));
        vbox.getChildren().addAll(carBrand, carModel, carColor, carYear, carLifeExpectancy, carYearOfProduction, carOwnedby, carPrice, carSeats, returnButton, submitButton);

        submitButton.setOnAction(event -> {
            String brand = carBrand.getText();
            String model = carModel.getText();
            String color = carColor.getText();
            int topSpeed = Integer.parseInt(carYear.getText());
            int lifeExpectancy = Integer.parseInt(carLifeExpectancy.getText());
            int yearOfProduction = Integer.parseInt(carYearOfProduction.getText());
            String ownedBy = carOwnedby.getText();
            int price = Integer.parseInt(carPrice.getText());
            int seats = Integer.parseInt(carSeats.getText());

            successfulOrNotScreenCarCreation(brand, model, color, ownedBy, topSpeed, lifeExpectancy, yearOfProduction, price, seats);

        });

        returnButton.setOnAction(event -> {
            showHomePage();
        });

    } // de tinut

    private void successfulOrNotScreenCarCreation(String brand, String model, String color, String owner, int topSpeed, int lifeExpectancy, int yearOfProduction, int price, int seats) {
        vbox.getChildren().clear();

        Button returnButton = new Button("Return to home page");

        Car new_car = new Car(brand, model, color, owner, topSpeed, lifeExpectancy, yearOfProduction, price, seats);

        boolean isStored = writeCarToDatabase(new_car);

        if (isStored) {
            Label successfulText = new Label("The Car has been added successfully!");
            vbox.getChildren().add(successfulText);
        } else {
            Label unsuccessfulText = new Label("Unfortunately, an error has occurred while adding the Car!");
            vbox.getChildren().add(unsuccessfulText);
        }

        returnButton.setOnAction(event -> {
            showHomePage();
        });

        vbox.getChildren().add(returnButton);
    }

    private void createNewClientScreen(){
        vbox.getChildren().clear();

        TextField clientFullName = new TextField();
        clientFullName.setPromptText("Full name:");

        TextField clientDoB = new TextField();
        clientDoB.setPromptText("Date of birth:");

        TextField clientBudget = new TextField();
        clientBudget.setPromptText("Budget:");

        Button createClient = new Button("Create");
        Button returnButton = new Button("Return");

        vbox.setPadding(new Insets(20, 50, 20, 50));
        vbox.getChildren().addAll(clientFullName, clientDoB, clientBudget, createClient, returnButton);


        createClient.setOnAction(event -> {
            String client_name = clientFullName.getText();
            String client_dob = clientDoB.getText();
            int client_budget = Integer.parseInt(clientBudget.getText());

            successfulOrNotScreenClientCreation(client_name, client_dob, client_budget);

        });

        returnButton.setOnAction(event -> {
            showHomePage();
        });
    } // de tinut

    private void successfulOrNotScreenClientCreation(String client_name, String client_dob, int client_budget) {
        vbox.getChildren().clear();

        Button returnButton = new Button("Return");

        Client new_client = new Client(client_name, client_dob, client_budget);

        boolean isStored = writeClientToDatabase(new_client);

        if (isStored) {
            Label successfulText = new Label("The Client has been added successfully!");
            vbox.getChildren().add(successfulText);
        } else {
            Label unsuccessfulText = new Label("Unfortunately, an error has occurred while adding the Client!");
            vbox.getChildren().add(unsuccessfulText);
        }

        returnButton.setOnAction(event -> {
            showHomePage();
        });

        vbox.getChildren().add(returnButton);
    } // de tinut

    private void findBest5CarsInputScreen(){
        vbox.getChildren().clear();

        TextField integerField = new TextField();
        integerField.setPromptText("Enter your budget:");

        vbox.setPadding(new Insets(20, 50, 20, 50));// spacing parameter sets the vertical space between nodes
        vbox.getChildren().addAll(integerField);

        Button submitBudgetButton = new Button("Submit Budget");
        Button returnButton = new Button("Return");

        returnButton.setOnAction(event -> {
            showHomePage();
        });

        vbox.getChildren().addAll(submitBudgetButton, returnButton);

        submitBudgetButton.setOnAction(e -> {
            try {
                int value = Integer.parseInt(integerField.getText());
                System.out.println("Entered value: " + value);

                List<CarAndDifference2Budget> carsAndDifferences = new ArrayList<>();
                for (Car car : cars) {
                    int difference = Math.abs(value - car.price);
                    Car car_to_add = car;
                    CarAndDifference2Budget new_set = new CarAndDifference2Budget(car_to_add, difference);
                    carsAndDifferences.add(new_set);
                }

                carsAndDifferences.sort((a, b) -> Integer.compare(a.difference, b.difference));
                carsAndDifferences = carsAndDifferences.subList(0, 5);

                vbox.getChildren().clear();

                System.out.println(carsAndDifferences);

                TableView<CarAndDifference2Budget> table = new TableView<>();
                ObservableList<CarAndDifference2Budget> data = FXCollections.observableArrayList(carsAndDifferences);

                // Name column
                TableColumn<CarAndDifference2Budget, String> brandColumn = new TableColumn<>("Brand");
                brandColumn.setCellValueFactory(new PropertyValueFactory<>("brand"));

                TableColumn<CarAndDifference2Budget, String> modelColumn = new TableColumn<>("Model");
                modelColumn.setCellValueFactory(new PropertyValueFactory<>("model"));

                TableColumn<CarAndDifference2Budget, Integer> difference2BudgetColumn = new TableColumn<>("Difference To Budget");
                difference2BudgetColumn.setCellValueFactory(new PropertyValueFactory<>("difference"));

                table.getColumns().add(brandColumn);
                table.getColumns().add(modelColumn);
                table.getColumns().add(difference2BudgetColumn);

                table.setItems(data);

                returnButton.setOnAction(event -> {
                    showHomePage();
                });

                vbox.setPadding(new Insets(20, 50, 20, 50));
                vbox.getChildren().addAll(table, returnButton);


            } catch (NumberFormatException ex) {
                System.out.println("Please enter a valid integer.");
            }

        });

    } // de tinut

    private void showAllCars(){
        vbox.getChildren().clear();

        TableView<Car> table = new TableView<>();
        ObservableList<Car> data = FXCollections.observableArrayList(cars);

        // Name column
        TableColumn<Car, String> brandColumn = new TableColumn<>("Brand");
        brandColumn.setCellValueFactory(new PropertyValueFactory<>("brand"));

        TableColumn<Car, String> modelColumn = new TableColumn<>("Model");
        modelColumn.setCellValueFactory(new PropertyValueFactory<>("model"));

        TableColumn<Car, String> colorColumn = new TableColumn<>("Color");
        colorColumn.setCellValueFactory(new PropertyValueFactory<>("color"));

        TableColumn<Car, Integer> topSpeedColumn = new TableColumn<>("Top Speed");
        topSpeedColumn.setCellValueFactory(new PropertyValueFactory<>("topSpeed"));

        TableColumn<Car, Integer> lifeExpectancyColumn = new TableColumn<>("Life Expectancy");
        lifeExpectancyColumn.setCellValueFactory(new PropertyValueFactory<>("lifeExpectancy"));

        TableColumn<Car, Integer> yearOfProductionColumn = new TableColumn<>("Year of Production");
        yearOfProductionColumn.setCellValueFactory(new PropertyValueFactory<>("yearOfProduction"));

        TableColumn<Car, String> ownedByColumn = new TableColumn<>("Owned By");
        ownedByColumn.setCellValueFactory(new PropertyValueFactory<>("ownedBy"));

        TableColumn<Car, Integer> priceColumn = new TableColumn<>("Price (EUR)");
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        TableColumn<Car, Integer> seatsColumn = new TableColumn<>("Seats");
        seatsColumn.setCellValueFactory(new PropertyValueFactory<>("seats"));

        table.getColumns().add(brandColumn);
        table.getColumns().add(modelColumn);
        table.getColumns().add(colorColumn);
        table.getColumns().add(topSpeedColumn);
        table.getColumns().add(lifeExpectancyColumn);
        table.getColumns().add(yearOfProductionColumn);
        table.getColumns().add(ownedByColumn);
        table.getColumns().add(priceColumn);
        table.getColumns().add(seatsColumn);

        table.setItems(data);

        Button returnButton = new Button("Return");

        returnButton.setOnAction(event -> {
            showHomePage();
        });

        vbox.setPadding(new Insets(20, 50, 20, 50));// spacing parameter sets the vertical space between nodes
        vbox.getChildren().addAll(table, returnButton);

    } // de tinut

    public void start(Stage primaryStage) {
        // runMainLogic();
        loginScreen(primaryStage);
    }

    public static void main(String[] args){
        launch(args);
    }
}