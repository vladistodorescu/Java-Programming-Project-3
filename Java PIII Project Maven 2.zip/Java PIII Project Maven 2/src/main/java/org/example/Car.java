package org.example;

import java.time.LocalDate;

public class Car implements VehicleOperations{
    protected String brand;
    protected String model;
    protected String color;
    protected int topSpeed;
    protected int lifeExpectancy;
    protected int yearOfProduction;
    protected String ownedBy;
    public int price;
    public int seats;


    public Car(String brand, String model, String color, String ownedBy, Integer topSpeed, int lifeExpectancy, int yearOfProduction, int price, int seats) {
        this.brand = brand;
        this.model = model;
        this.color = color;
        this.topSpeed = topSpeed;
        this.lifeExpectancy = lifeExpectancy;
        this.yearOfProduction = yearOfProduction;
        this.ownedBy = ownedBy;
        this.price = price;
        this.seats = seats;
    }

    public void remainingLifeOfCar(){
        int yearOfProduction = this.yearOfProduction;
        int lifeExpectancy = this.lifeExpectancy;
        int currentYear = LocalDate.now().getYear();
        int lifeRemaining = lifeExpectancy - (currentYear - yearOfProduction);
        if (lifeRemaining <= 0){
            OutputDevice.writeToTerminal("Unfortunately, this car has no more years of guaranteed functioning remaining.");
        }
        else{
            OutputDevice.writeToTerminal("This car has about " + lifeRemaining + " years of guaranteed functioning remaining.");
        }
    }

    public void applyDiscount(int discount){
        this.price = this.price - discount/100 * this.price;
    }

    @Override
    public void displayVehicleInformation(){
        OutputDevice.writeToTerminal("Brand: "  + this.brand + "\n" + "Model: " + this.model + "\n"
                + "Color: " + this.color + "\n" +"Seats: " + this.seats +  "\n" + "Top Speed: " + this.topSpeed
                + " km/h\n" + "Year of Production: " + this.yearOfProduction + "\n" + "Price: " + this.price + "\n");
    }

    @Override
    public void scheduleMaintenance() {
        OutputDevice.writeToTerminal("Car maintenance scheduled.");
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getTopSpeed() {
        return topSpeed;
    }

    public void setTopSpeed(int topSpeed) {
        this.topSpeed = topSpeed;
    }

    public int getLifeExpectancy() {
        return lifeExpectancy;
    }

    public void setLifeExpectancy(int lifeExpectancy) {
        this.lifeExpectancy = lifeExpectancy;
    }

    public int getYearOfProduction() {
        return yearOfProduction;
    }

    public void setYearOfProduction(int yearOfProduction) {
        this.yearOfProduction = yearOfProduction;
    }

    public String getOwnedBy() {
        return ownedBy;
    }

    public void setOwnedBy(String ownedBy) {
        this.ownedBy = ownedBy;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }
}



